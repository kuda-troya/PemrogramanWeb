<?php

include "koneksi.php";

$tombol = $_POST['tombol'];

if($tombol=="Tambah")
{
    ?>
    <h2>Form Input Mahasiswa</h2>
    <form method="POST" action="eksekusi.php">
    nim : <input type="TEXT" name="nim"><br>
    nama: <input type="TEXT" name="nama"><br>
    <input type="SUBMIT" name="tombol" value="Simpan">
    <?php
}
elseif($tombol=="Edit")
{
    $id_mhs = $_POST['id_mhs'];
    $data = mysqli_query($koneksi,"SELECT * FROM tbl_mhs WHERE id_mhs='$id_mhs'");
    $d = mysqli_fetch_array($data);
    ?>
    <h2>Form Edit Mahasiswa</h2>

    <form method="POST" action="eksekusi.php">
    <input type="hidden" name="id_mhs" value="<?php echo"$id_mhs";?>">
    nim : <input type="TEXT" name="nim" value="<?php echo"$d[nim]";?>"><br>
    nama: <input type="TEXT" name="nama" value="<?php echo"$d[nama]";?>"><br>
    <input type="SUBMIT" name="tombol" value="Update">
    </form>
    <?php
}
elseif($tombol=="Simpan")
{
    mysqli_query($koneksi,"INSERT INTO tbl_mhs VALUES('','$_POST[nim]','$_POST[nama]')");
    echo "<h2>Data Berhasil diSimpan</h2>";
    header('Refresh:3;url=tampil.php');
    exit;
}
elseif($tombol=="Update")
{
    mysqli_query($koneksi,"UPDATE tbl_mhs SET nim='$_POST[nim]', nama='$_POST[nama]' WHERE id_mhs='$_POST[id_mhs]'");
    echo "<h2>Data Berhasil diUpdate</h2>";
    header('Refresh:3;url=tampil.php');
    exit;
}
elseif($tombol=="Hapus")
{
    mysqli_query($koneksi,"DELETE FROM tbl_mhs WHERE id_mhs='$_POST[id_mhs]'");
    echo "<h2>Data Berhasil diDelete</h2>";
    header('Refresh:3;url=tampil.php');
    exit;
}