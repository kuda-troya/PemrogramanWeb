<!DOCTYPE html>
<html>
<body>

<h2>Form Login</h2>
<?php 
	if(isset($_GET['pesan'])){
		if($_GET['pesan'] == "gagal"){
			echo "Login gagal! username dan password salah!";
		}else if($_GET['pesan'] == "logout"){
			echo "Anda telah berhasil logout";
		}else if($_GET['pesan'] == "belum_login"){
			echo "Anda harus login untuk mengakses halaman admin";
		}
	}
?>
<form action="login_exe.php" method="post">
  <label for="username">Username:</label><br>
  <input type="text" id="username" name="username" placeholder="Username"><br>
  <label for="password">Password:</label><br>
  <input type="password" id="password" name="password" placeholder="Password"><br><br>
  <input type="submit" value="Submit">
</form> 

<p>Belajar Pemrograman Web</p>

</body>
</html>

