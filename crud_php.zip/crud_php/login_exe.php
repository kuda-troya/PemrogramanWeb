<?php
session_start();
include "koneksi.php";
$username=$_POST['username'];
$password=md5($_POST['password']);

$cek=mysqli_query($koneksi,"SELECT * FROM tbl_pengguna WHERE username='$username' AND password='$password' AND Aktif='Enabel'");

if(mysqli_num_rows($cek) > 0)
{
    $_SESSION['username']=$username;
    $_SESSION['status']="login";
    header("location:admin/index.php");
}else{
    header("location:login.php?pesan=gagal");
}
?>