<h2>Data Mahasiswa</h2>

<form method="POST" action="eksekusi.php">
Tambah data : <input type="submit" name="tombol" value="Tambah">
</form>

<table border="1">
<tr>
    <th>Id</th>
    <th>Nim</th>
    <th>Nama</th>
    <th>Pilihan</th>
</tr>
<?php
include "koneksi.php";
$no = 1;

$data = mysqli_query($koneksi,"SELECT * FROM tbl_mhs");
while($d = mysqli_fetch_array($data)){
?>
<tr>
    <td><?php echo $no++;?></td>
    <td><?php echo $d["nim"];?>
    <td><?php echo $d["nama"];?>
    <td>
        <form method="POST" action="eksekusi.php">
        <input type="hidden" name="id_mhs" value="<?php echo $d['id_mhs'];?>">
        <input type="submit" name="tombol" value="Edit">
        <input type="submit" name="tombol" value="Hapus">
        </form>
    </td>
</tr>
<?php
}
?>
</table>
