<html>
<head>
<title>Perkenalan PHP</title>
</head>
<body>
<?php
echo"Belajar Pemrograman PHP";
?>
</body>
</html>