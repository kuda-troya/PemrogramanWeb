<?php
echo"Belajar Pemrograman PHP";
?>