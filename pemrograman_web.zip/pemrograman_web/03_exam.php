<?php
//Penulisan varibel
$nim = "G.211.00.0001";
$nama= "Giant Suneo";
$fak = "FTIK";
$pro = "Teknik Informatika";

echo "<h2>Data Pribadi Mahasiswa</h2>";
echo "Nim : ".$nim."<br>";
echo "Nama : ".$nama."<br>";
echo "Fakultas : ".$fak."<br>";
echo "Program Studi : ".$pro;
?>