<html>
<head>
<title>Form Php</title>
</head>
<body>
<h2>Form Sederhana</h2>
<form method="POST" action="05_exam.php">
Nama : <input type="TEXT" name="nama"><br>
Alamat : <input type="TEXT" name="alamat"><br>
<input type="SUBMIT" name="proses" value="PROSES">
</form>
</body>
</html>