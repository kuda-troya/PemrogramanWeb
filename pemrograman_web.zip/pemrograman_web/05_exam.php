<?php
$nama=$_POST['nama'];
$alamat=$_POST['alamat'];
echo "Hallo perkenalkan nama saya <b>".$nama."</b><br>";
echo "Alamat rumah saya ada di <b>".$alamat."</b>";
?>