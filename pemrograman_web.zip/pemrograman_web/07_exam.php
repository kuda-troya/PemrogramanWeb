<?php
$nama=$_POST['nama'];
$alamat=$_POST['alamat'];
$jenis_kelamin=$_POST['jenis_kelamin'];
$program_studi=$_POST['program_studi'];
$hobi=$_POST['hobi'];

echo"<h2>My Profile</h2>";

echo"Nama saya ".$nama." alamat rumah saya di ".$alamat."<br>";
echo"Jenis kelamin saya ".$jenis_kelamin."<br>";
echo"Ambil Program Studi ".$program_studi."<br>";
echo"Hobi saya antara lain :";
$hit=count($hobi);
for($i=0; $i<$hit; $i++)
{
    echo $hobi[$i].",";
}
?>