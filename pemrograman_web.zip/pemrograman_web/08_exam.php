<?php
$ipk = 2.3;
echo"<h2>Keterangan IPK =".$ipk."</h2>";
if ($ipk  <= 2.75) {
    echo "<b>Belajar Lagi</b>";
} elseif ($ipk  <= 3) {
    echo "<b>Memuaskan</b>";
} elseif ($ipk  >= 3.51) {
    echo "<b>Sangat Memuaskan</b>";
} elseif($ipk  >= 3.51) {
    echo "<b>Cumlaude</b>";
} else {
    echo"<b>Anda Belum Beruntung</b>";
}
?>