<?php
$x = 1;
echo"<h2>Contoh While Loop</h2>";
while($x <= 5) {
    echo "Nomor Ke: $x <br>";
    $x++;
}
?>