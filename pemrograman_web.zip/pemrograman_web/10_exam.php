<?php
$x = 1;
echo"<h2>Contoh Do While</h2>";
do {
  echo "Urutan Nomor Ke: $x <br>";
  $x++;
} while ($x <= 5);
?>
