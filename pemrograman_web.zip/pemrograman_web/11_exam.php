<?php
echo"<h2>Contoh For Loop</h2>";
for ($x = 0; $x <= 10; $x++) {
  echo "$x. Aku janji tidak mengulangi lagi<br>";
}
?>