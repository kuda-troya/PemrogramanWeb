<?php  
echo"<h2>Contoh Foreach</h2>";
$colors = array("Sistem Informasi", "Teknik Informatika", "Ilmu Komunikasi","Pariwisata"); 

foreach ($colors as $value) {
echo "$value <br>";
}
?> 