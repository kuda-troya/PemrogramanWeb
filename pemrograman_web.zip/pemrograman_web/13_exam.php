<!DOCTYPE html>
<html>
<body>
<h2>Form Upload Gambar</h2>
<form action="15_exam.php" method="post" enctype="multipart/form-data">
  Pilih Gambar Untuk di Upload
  <input type="file" name="filename" id="filename">
  <input type="submit" value="Upload Image" name="submit">
</form>

</body>
</html>